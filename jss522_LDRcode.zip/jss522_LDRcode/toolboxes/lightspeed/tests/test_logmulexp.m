a = rand(3,1);
b = rand(1,4);

log(exp(a)*exp(b))
logmulexp(a,b)
