function [M,N] = MN4pfcord(Sfit,S)

M = Sfit;
N = S;
